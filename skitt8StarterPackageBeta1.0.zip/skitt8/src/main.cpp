#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <bitset>
#include <functional>
#include <cstdint>
#include <sstream>
#include <filesystem>
#include <chrono>
#include <thread>


#include "debugger.hpp"


class Chip{
    public:
        int chipCode = -1;
        std::string name = "N";

        virtual void callINS(int command, std::vector<int> arggs){
            debugger.writeLine("(!!)-- 'callINS' is not defined!", debugger.errorLevels.FATALERRORS, debugger.colors.RED);
            std::terminate();
        }
};

class RES : public Chip{

    public:
        int value = 0;

        void clear(){
            value = 0;
        }


};

std::vector<Chip*> allChips = {};

template <typename T>
T * getChip(int chipCode){
    for(int i=0; i < allChips.size(); i++){
        if(allChips[i]->chipCode == chipCode){
            T* chip = dynamic_cast<T*>(allChips[i]);
            if(chip != nullptr)
                return chip;
            else{
                debugger.writeLine("(!!)-- Could not cast chip", debugger.errorLevels.FATALERRORS, debugger.colors.RED);
                return nullptr;
            }
        }
    }
    debugger.writeLine("(!!)-- Could not find chip", debugger.errorLevels.FATALERRORS, debugger.colors.RED);
    return nullptr;
}

std::vector<std::string> readFileAndProcess(const std::string& filename) {
    std::ifstream file(filename);
    std::vector<std::string> lines;

    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return lines;
    }

    std::string line;
    while (std::getline(file, line)) {
        // Replace semicolons with newlines
        std::string modifiedLine;
        for (char c : line) {
            if (c == ';') {
                modifiedLine += '\n';  // Replace semicolon with newline
            }
            else if(c == ' '){
                
            } 
            else {
                modifiedLine += c;  // Keep other characters
            }
        }
        lines.push_back(modifiedLine);  // Add the modified line to the vector
    }

    return lines;
}

std::vector<std::string> split(const std::string& str, char delimiter) {
    std::vector<std::string> result;
    std::stringstream ss(str);
    std::string token;

    while (std::getline(ss, token, delimiter)) {
        result.push_back(token);
    }

    return result;
}

double clockSpeedDelay = 83;

int unsigned programCounter = 0;

int lastBusData = -1;

bool busWasChangedLastClockTick = false;

bool jumpedThisClockTick = false;

bool runClock = true;

// the ALU is werild so ill just do this
int ALUvalue = -1;

class RESA;
class RESB;
class RESC;
class BUS;
class IO;
class AU;
class LU;
class RAMCHIP;
class RAMRES;

RESA * resA;
RESB * resB;
RESC * resC;

BUS * bus;

AU * au;
LU * lu;

IO * io;

RAMCHIP * ramChip;

class BUS : public RES{

    public:

        void callINS(int command, std::vector<int> arggs) override{
            switch (command)
            {
                case 0:
                    value = arggs[0];
                
                default:
                    break;
            }
        }

        BUS(std::string Name, int ChipCode){
            name = Name;
            chipCode = ChipCode;
        }

};

class RESB : public RES{

    public:

        void callINS(int command, std::vector<int> arggs) override;

        RESB(std::string Name, int ChipCode){
            name = Name;
            chipCode = ChipCode;
        }

};

class RESA : public RES{

    public:

        void callINS(int command, std::vector<int> arggs) override;

        RESA(std::string Name, int ChipCode){
            name = Name;
            chipCode = ChipCode;
        }

};

class RESC : public RES{

    public:

        void callINS(int command, std::vector<int> arggs) override;

        RESC(std::string Name, int ChipCode){
            name = Name;
            chipCode = ChipCode;
        }

};


void RESA::callINS(int command, std::vector<int> arggs){
    switch (command)
    {
        case 0:
            value = bus->value;
            break;
        
        case 1:
            value = arggs[0];
            break;
        
        case 2:
            // debugger.writeLine("writeing to BUS" + std::to_string(value));
            bus->value = value;
            busWasChangedLastClockTick = false;
            break;

        case 15:
            int myOldVal = value;
            value = resB->value;
            resB->value = myOldVal;
            break;
            
    }
}

void RESB::callINS(int command, std::vector<int> arggs){
    switch (command)
    {
        case 0:
            value = bus->value;
            break;
        
        case 1:
            value = arggs[0];
            break;
        
        case 2:
            bus->value = value;
            busWasChangedLastClockTick = false;
            break;

        case 15:
            int myOldVal = value;
            value = resC->value;
            resC->value = myOldVal;
            break;
            
    }
}


void RESC::callINS(int command, std::vector<int> arggs){
    switch (command)
    {
        case 0:
            value = bus->value;
            break;
        
        case 1:
            value = arggs[0];
            break;
        
        case 2:
            bus->value = value;
            busWasChangedLastClockTick = false;
            break;

        case 15:
            int myOldVal = value;
            value = resA->value;
            resA->value = myOldVal;
            break;
            
    }
}


class AU : public Chip{

    public:


        void clear(){
            ALUvalue = 0;
        }

        void callINS(int command, std::vector<int> arggs) override{
            switch (command)
            {
                case 0:
                    ALUvalue = resA->value + resB->value;
                    break;
                
                case 1:
                    resA->value = resA->value + resB->value;
                    break;
                
                case 2:
                    ALUvalue = resA->value - resB->value;
                    break;
                case 3:
                    resA->value = resA->value - resB->value;
                    break;

                // case 4:
                //     ALUvalue = arggs[0] + arggs[1];
                //     break;

                // case 5:
                //     resA->value = arggs[0] + arggs[1];
                //     break;

                case 6:
                    bus->value = ALUvalue;
                    busWasChangedLastClockTick = false;
                    break;

            }
        }

        AU(std::string Name, int ChipCode){
            name = Name;
            chipCode = ChipCode;
        }
    
};

class LU : public Chip{

    public:


        void clear(){
            ALUvalue = 0;
        }

        void callINS(int command, std::vector<int> arggs) override{
            switch (command)
            {
                case 0:
                    if(resA->value == resB->value){
                        ALUvalue = 1;
                    }
                    else{
                        ALUvalue = 0;
                    }
                    break;
                
                case 1:
                    if(resA->value == arggs[0]){
                        ALUvalue = 1;
                    }
                    else{
                        ALUvalue = 0;
                    }
                    break;
                
                case 6:
                    if(ALUvalue == 0){
                        jumpedThisClockTick = true;
                        programCounter = arggs[0];
                    }
                    break;
                case 7:
                    if(ALUvalue != 0){
                        jumpedThisClockTick = true;
                        programCounter = arggs[0];
                    }
                    break;
                
                case 8:
                    break;
                
                case 9:
                    jumpedThisClockTick = true;
                    programCounter = arggs[0];
                    break;
                case 10:
                    jumpedThisClockTick = true;
                    programCounter = bus->value;
                    break;
                
                case 15:
                    debugger.writeLine("(!?)-- the computer has halted", debugger.errorLevels.WARRINGS, debugger.colors.YELLOW);
                    std::terminate();
                    break;
                
                // case 4:
                    
                //     break;

                // case 5:
                    
                //     break;

                // case 6:
                //     break;

                // case 7:
                    
                //     break;

            }
        }

        LU(std::string Name, int ChipCode){
            name = Name;
            chipCode = ChipCode;
        }
    
};

class IO : public Chip{
    public:

        void callINS(int command, std::vector<int> arggs) override{
            std::string input = "";
            switch (command)
            {
                case 0:
                    debugger.write(bus->value);
                    break;
                
                case 1:
                    debugger.write(char(bus->value));
                    break;

                case 2:
                    debugger.write(arggs[0]);
                    break;
                
                case 3:
                    debugger.write(char(arggs[0]));
                    break;
                
                case 4:
                    runClock = false;

                   input = debugger.getInput("");
                    if(input.size() > 0){
                        bus->value = int(input.at(0));
                    }
                    else{
                        bus->value = 0;
                    }

                    runClock = true;
                    break;

                case 5:
                    runClock = false;

                    input = debugger.getInput("");
                    if(input.size() > 0){
                        busWasChangedLastClockTick = false;
                        bus->value = stoi(input);
                    }
                    else{
                        busWasChangedLastClockTick = false;
                        bus->value = 0;
                    }

                    runClock = true;
                    break;


            }
        }

        IO(std::string Name, int ChipCode){
            name = Name;
            chipCode = ChipCode;
        }
};

class RAMRES{
    public:
        int value = 0;

        RAMRES(int Value){
            value = Value;
        }
};

class RAMCHIP : public Chip{

    public:

        int unsigned RAMSizeSector = 0;
        int unsigned RAMSectors = 0;

        std::vector<std::vector<RAMRES*>> RAMData = {};

        void callINS(int command, std::vector<int> arggs) override {
            switch (command) {
                case 0:
                    bus->value = RAMData[arggs[0]][arggs[1]]->value;
                    busWasChangedLastClockTick = false;
                    break;

                case 1:
                    resA->value = RAMData[arggs[0]][arggs[1]]->value;
                    break;

                case 2:
                    resB->value = RAMData[arggs[0]][arggs[1]]->value;
                    break;

                case 3:
                    RAMData[arggs[0]][arggs[1]]->value = bus->value;
                    break;

                case 4:
                    RAMData[arggs[0]][arggs[1]]->value = resA->value;
                    break;

                case 5:
                    RAMData[arggs[0]][arggs[1]]->value = resB->value;
                    break;
                
                case 6:
                    // debugger.writeLine("writein to bus");
                    // debugger.writeLine(resA->value);
                    // debugger.writeLine(resB->value);
                    bus->value = RAMData[resA->value][resB->value]->value;
                    busWasChangedLastClockTick = false;
                    break;
                
                case 7:
                    resC->value = RAMData[resA->value][resB->value]->value;
                    break;


                case 8:
                    // debugger.writeLine("readin from bus");
                    
                    RAMData[resA->value][resB->value]->value = bus->value;
                    
                    // if(rand()%2550 == 0){
                    //     RAMData[resA->value][resB->value]->value = rand()%255;
                    //     debugger.writeLine("damgeing RAM");
                    //     debugger.writeLine(resA->value);
                    //     debugger.writeLine(resB->value);
                    // }
                    break;

                case 9:
                    RAMData[resA->value][resB->value]->value = resC->value;
                    break;


                default:
                    break;
            }
        }


        RAMCHIP(std::string Name, int ChipCode, unsigned int RAMSizeSector, unsigned int RAMSectors) {
            name = Name;
            chipCode = ChipCode;
            this->RAMSizeSector = RAMSizeSector;
            this->RAMSectors = RAMSectors;

            // Initialize RAMData with RAMSectors vectors, each containing RAMSizeSector RAMRES objects
            RAMData.resize(RAMSectors);
            for (unsigned int i = 0; i < RAMSectors; ++i) {
                for (unsigned int j = 0; j < RAMSizeSector; ++j) {
                    RAMData[i].push_back(new RAMRES(0));
                }
            }
        }


};

class programCommand{
    public:
        int targetChip = -1;

        int command = -1;

        std::vector<int> arggs = {};

        programCommand(int TargetChip, int Command, std::vector<int> Arggs){
            command = Command;
            targetChip = TargetChip;
            arggs = Arggs;

        }
        
        void operator()() const {
            getChip<Chip>(targetChip)->callINS(command, arggs);
        }
};

class PROGRAMCOUNTER : public RES{

    public:

        void callINS(int command, std::vector<int> arggs) override{
            switch (command)
            {
                case 0:
                    value = programCounter;
                    break;
                
                case 1:
                    bus->value = value;
                    busWasChangedLastClockTick = false;
                
                case 2:
                    value = programCounter+2;
                    
            }
        }

        PROGRAMCOUNTER(std::string Name, int ChipCode){
            name = Name;
            chipCode = ChipCode;
        }

};

std::ostream& operator<<(std::ostream& os, const RES& res) {
    os << "\n-------------------------------\n";
    os << "| " << res.name << ", chip code: " << res.chipCode << ", value: " << res.value << " |";
    os << "\n-------------------------------\n";
    return os;
}

std::ostream& operator<<(std::ostream& os, const programCommand& commands) {
    os << "\n-------------------------------\n";
    os << "| " << commands.targetChip << ", INS: " << commands.command << ", arggs: (" << commands.arggs[0] << ", " << commands.arggs[1] << ") |";
    os << "\n-------------------------------\n";
    return os;
}

std::ostream& operator<<(std::ostream& os, const RAMRES& res) {
    os << res.value;
    return os;
}

std::vector<programCommand> program = {};

int unsigned programLines = 0;

std::filesystem::path currentPath;

std::filesystem::path oldPath;

const char * installDir = "C:\\Users\\wjust\\OneDrive\\Desktop\\cpp_code\\skitt8";

bool debugPrints = false;

int main(int argc, char *argv[]){

    srand(time(0));
    
    std::vector<std::string> flags;

    for (int i = 1; i < argc; ++i) { // Start from 1 to skip the program name
        std::string arg = argv[i];
        if (!arg.empty() && arg[0] == '-') {
            flags.push_back(arg);
        }
    }


    debugger.errorLevel = debugger.errorLevels.ALL;
    
    std::vector<std::string> fileContents = {};

    for(int i=0; i < flags.size(); i++){
        if(flags[i] == "-help"){
            debugger.writeLine("_-_-_-_-_Skitt inc. Skitt8 Emulator help_-_-_-_-_");
            debugger.writeLine("    Commands: ");
            debugger.writeLine("        -help, shows this screen ");
            debugger.writeLine("        -show, shows chips and there data and state ");
            debugger.writeLine("        -debugOff, turns off ALL prints including errors");
            debugger.writeLine("    Usage: ");
            debugger.writeLine("        To run a .skitt8 file do 'skitt8Emulator yourProgram.skitt8'");
            debugger.writeLine("        To add any flags put them at the END: 'skitt8Emulator yourProgram.skitt8 -coolFlag'");
        }   
        else if(flags[i] == "-show"){
            debugPrints = true;
        }
        else if(flags[i] == "-debugOff"){
            debugger.errorLevel = debugger.errorLevels.NONE;
        }
    }

    if(argc > 1 && argv[1][0] != '-'){
        fileContents = readFileAndProcess(argv[1]);
    }
    else{
        if(flags.size() == 0){
            debugger.writeLine("(!!)-- Give a .skitt8 file to run!", debugger.errorLevels.FATALERRORS, debugger.colors.RED);
            return 1;
        }
        else{
            return 0;
        }
    }


    std::string input = debugger.getInput("(??)-- Add a delay to the clock speed in microseconds if not hit enter: ", debugger.colors.YELLOW);
    
    if(input != "\n" && input != "" && input != " "){
        try{
            clockSpeedDelay = std::stod(input);
            debugger.writeLine("(*)-- set clock delay to: " + std::to_string(clockSpeedDelay), debugger.errorLevels.NOTES, debugger.colors.BLUE);
        }
        catch(...){
            debugger.writeLine("(!?)-- invaild input clock delay set to 0", debugger.errorLevels.WARRINGS, debugger.colors.YELLOW);
        }
        
    }

    try {
        for(std::string str : fileContents){
            if(str != " " && str != "\n"){
                std::vector<std::string> temp = split(str, '|');
                std::vector<std::string> temp2 = split(temp[1], '[');
                std::vector<std::string> oppCodes = {};
                
                temp2[1].erase(std::remove(temp2[1].begin(), temp2[1].end(), ']'), temp2[1].end());


                std::vector<std::string> temp3 = split(temp2[1], ',');


                std::vector<int> arggs = {std::stoi(temp3[0]), std::stoi(temp3[1])};

                oppCodes.push_back(temp[0]);
                oppCodes.push_back(temp2[0]);

                program.push_back(programCommand(
                    std::bitset<64>(oppCodes[0]).to_ulong(),
                    std::bitset<64>(oppCodes[1]).to_ulong(),
                    arggs
                ));
            }
        }
    }
    catch(...){
        debugger.writeLine("(!!)-- file could not be prased exiting...", debugger.errorLevels.FATALERRORS, debugger.colors.RED);
        std::terminate();
    }

    debugger.writeLine("(*)-- File prased!", debugger.errorLevels.NOTES, debugger.colors.GREEN);

    programLines = program.size();

    // DO NOT LEAK MERMORY PLSSSS
    allChips.push_back(new RESA("A", 0));
    allChips.push_back(new RESB("B", 1));
    allChips.push_back(new RESC("C", 5));

    allChips.push_back(new BUS("BUS", 2));

    allChips.push_back(new AU("AU", 3));
    allChips.push_back(new LU("LU", 4));

    allChips.push_back(new IO("IO", 6));

    allChips.push_back(new RAMCHIP("RAMChip", 7, 255, 255));

    allChips.push_back(new PROGRAMCOUNTER("PROGRAMCOUNTER", 8));

    resA = getChip<RESA>(0);
    resB = getChip<RESB>(1);
    resC = getChip<RESC>(5);

    bus = getChip<BUS>(2);

    io = getChip<IO>(6);

    ramChip = getChip<RAMCHIP>(7);

    lastBusData = bus->value;

    debugger.writeLine("(*)-- Starting skitt8 emulator...", debugger.errorLevels.NOTES, debugger.colors.BLUE);

    while (programCounter < programLines){
        if(runClock){
            

            if(clockSpeedDelay != 0){
                
                // Record the start time
                auto start = std::chrono::high_resolution_clock::now();

                // Loop until 100 microseconds have passed
                while (true) {
                    auto now = std::chrono::high_resolution_clock::now();
                    auto elapsed = std::chrono::duration_cast<std::chrono::microseconds>(now - start);
                    if (elapsed.count() >= clockSpeedDelay) {
                        break;
                    }
                }

            }

            program[programCounter]();

            

            if(!jumpedThisClockTick){
                programCounter ++;
            }
            else{
                jumpedThisClockTick = false;
            }

            if(busWasChangedLastClockTick){
                bus->clear();
                busWasChangedLastClockTick = false;
                // debugger.writeLine("BUS was cleared!");
            }

            else if(lastBusData != bus->value){
                lastBusData = bus->value;
                busWasChangedLastClockTick = true;
            }
            
            if(debugPrints){
                debugger.writeLine("___________________ PROGRAM COUNTER " + std::to_string(programCounter) + "___________________");
                debugger.write(*resA);
                debugger.write(*resB);
                debugger.write(*resC);

                debugger.write(*bus);

                debugger.write("\n");
            }
        }
        
    }

    debugger.writeLine("(*)-- skitt8 emulator has ran your program exiting...", debugger.errorLevels.NOTES, debugger.colors.GREEN);
    
    for (Chip* chip : allChips) {
        delete chip;
    }

    debugger.writeLine("(*)-- done!", debugger.errorLevels.NOTES, debugger.colors.GREEN);

    return 0;
}