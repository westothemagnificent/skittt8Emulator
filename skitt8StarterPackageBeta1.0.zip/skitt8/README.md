Instructions:

instruction = "INS"
chip target  "CT"

Register = "RES"

FORMAT:

     CT    INS  arggs
     |      |     |
     v      v     v

    0000|0000[0, 0]


ALL CHIP CODES:

    0000 RES A (Accumulator)

    0001 RES B

    0010 RES BUS

    0011 AU RES

    0100 LU RES

    0101 RES C

    0110 IO

    0111 RAM

    1000 PROGRAMCOUNTER

    yes, the ALU is a Register


NOTES:

    WHEN AND ONLY WHEN data is put on the main data bus(most chips can read from) does not clear untill AFTER next clock cycle

    all chips trigger on high side of the clock expect BUS
    JMP calls are aubsolte by seting the program counter to ARRG 1

    all ARGGS HAVE to be 8 bit there is a max of two arggs

    the bus has no adress chips can read from the bus when every where every they want

    also any invaild INS are just NOPs.

    AU and LU share their RES

Registers Instructions:

    RES A:

        0000 0000 | NO ARRGS, load RES A with current BUS data

        0000 0001 | ARRGS 1, load RES A with ARRG 1

        0000 0010 | NO ARRGS, output RES A to BUS

        0000 1111 | NO ARRGS, swap A and B RES

    RES B:

        0001 0000 | NO ARRGS, load RES B with current BUS data

        0001 0001 | ARRGS 1, load RES B with ARRG 1

        0001 0010 | NO ARRGS, output RES B to BUS

        0001 1111 | NO ARRGS, swap B and C RES

    RES C:

        0101 0000 | NO ARRGS, load RES C with current BUS data

        0101 0001 | ARRGS 1, load RES C with ARRG 1

        0101 0010 | NO ARRGS, output RES C to BUS

        0101 1111 | NO ARRGS, swap C and A RES

    BUS:

        // 0010 0001 | ARRGS 1, load RES BUS with ARRG 1

        0010 0000 | ARRGS 1, load RES BUS with ARRG 1

    ALU:
        0011 0010 | NO ARRGS, output RES ALU RES to BUS
    


AU:

    0011 0000 | NO ARRGS, add A and B RES and store in ALU RES

    0011 0001 | NO ARRGS, add A and B RES and store in A(accumulator) RES

    0011 0010 | NO ARRGS, sub A and B RES and store in ALU RES

    0011 0011 | NO ARRGS, sub A and B RES and store in A(accumulator) RES

    // 0011 0100 | ARRGS 2, add ARGG 1 and ARGG 2 and store in ALU RES

    // 0011 0101 | ARRGS 2, add ARGG 1 and ARGG 2 and store in A(accumulator) RES

    0011 0110 | NO ARRGS, output ALU RES to BUS

LU:
    0100 0000 | NO ARGGS, check if RES A and RES B are the same if so sets the ALU RES to 1 otherwise 0
    0100 0001 | ARGGS 1, check if RES A and ARRG 1 are the same if so sets the ALU RES to 1 otherwise 0

    0100 0010 | NO ARGGS, check if RES A > RES B if so sets the ALU RES to 1 otherwise 0
    0100 0011 | ARGGS, check if RES A > ARGG 1 if so sets the ALU RES to 1 otherwise 0

    0100 0100 | NO ARGGS, check if RES A < RES B if so sets the ALU RES to 1 otherwise 0
    0100 0101 | ARGGS, check if RES A < ARGG 1 if so sets the ALU RES to 1 otherwise 0

    0100 0110 | ARGGS 1, checks if ALU RES is zero if so jumps to ARGG 1
    0100 0111 | ARGGS 1, checks if ALU RES is not zero if so jumps to ARGG 1
    
    0100 1000 | NO ARGGS, NOP, does nothing just takes up a clock cycle

    0100 1001 | ARRGS 1, jumps to ARRG 1

    0100 1010 | NO ARRGS, jumps to BUS DATA

    0100 1111 | NO ARGGS, halts the computer

IO:
    0110 0000 | NO ARGGS, outputs current BUS data to console as an int (ONLY FOR EMUATOR) other wise its a NOP
    0110 0001 | NO ARGGS, outputs current BUS data to console as an char (ONLY FOR EMUATOR) other wise its a NOP
    0110 0010 | ARGGS 1, outputs current ARGG 1 data to console as an int (ONLY FOR EMUATOR) other wise its a NOP
    0110 0011 | ARGGS 1, outputs current ARGG 1 data to console as an char (ONLY FOR EMUATOR) other wise its a NOP

    0110 0100 | NO ARGGS, grabs input from console as an char and sets the BUS data to input NOTE input is AWLAYS a char (ONLY FOR EMUATOR) other wise its a NOP, PUASES THE COMPUTER
    0110 0101 | NO ARGGS, grabs input from console as an int and sets the BUS data to input NOTE input is AWLAYS a int (ONLY FOR EMUATOR) other wise its a NOP, PUASES THE COMPUTER

RAM:
    0111 0000 | ARGGS 2, get value from ram at ARGG 1 in sector ARGG 2 and write value to BUS
    0111 0001 | ARGGS 2, get value from ram at ARGG 1 in sector ARGG 2 and write value to RES A
    0111 0010 | ARGGS 2, get value from ram at ARGG 1 in sector ARGG 2 and write value to RES B 

    0111 0011 | ARGGS 2, set value from ram at ARGG 1 in sector ARGG 2 and set to BUS data    
    0111 0100 | ARGGS 2, set value from ram at ARGG 1 in sector ARGG 2 and set to RES A
    0111 0101 | ARGGS 2, set value from ram at ARGG 1 in sector ARGG 2 and set to RES B

    0111 0110 | NO ARGGS, get value from ram at A in sector B and output to BUS    
    0111 0111 | NO ARGGS, get value from ram at A in sector B and output to RES C

    0111 1000 | NO ARGGS, set value from ram at A in sector B and set to BUS data    
    0111 1001 | NO ARGGS, set value from ram at A in sector B and set to RES C

PROGRAMCOUNTER:
    1000 0000 | NO ARGGS, save current PROGRAMCOUNTER value in RES
    1000 0001 | NO ARGGS, output current RES value to BUS
    1000 0010 | NO ARGGS, save current PROGRAMCOUNTER two ahead value in RES