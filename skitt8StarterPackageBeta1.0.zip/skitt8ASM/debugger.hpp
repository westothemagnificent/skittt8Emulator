#include <iostream>
#include <vector>
#include <string>

class{
    public:

    class ErrorLevels{
        public:
            const unsigned short NONE = 0;
            const unsigned short ALL = 1;
            const unsigned short NOTES = 2;
            const unsigned short WARRINGS = 3;
            const unsigned short ERRORS = 4;
            const unsigned short FATALERRORS = 5;
            
    };

    class Colors{
        public:
            const unsigned int RED = 31;
            const unsigned int GREEN = 32;
            const unsigned int YELLOW = 33;
            const unsigned int BLUE = 34;

    };

    ErrorLevels errorLevels = ErrorLevels();
    Colors colors = Colors();

    unsigned short errorLevel = errorLevels.ALL;

    template <typename T>
    void writeLine(T str){
        std::cout << str << "\n";
    }

    template <typename T>
    void writeLine(T str, unsigned short e){
        if(errorLevel == errorLevels.ALL || e == errorLevel && errorLevel != errorLevels.NONE){
            std::cout << str << "\n";
        }
    }

    template <typename T>
    void writeLine(T str, unsigned short e, unsigned int c){
        std::cout << "\033[" << c << "m";
        if(errorLevel == errorLevels.ALL || e == errorLevel && errorLevel != errorLevels.NONE){
            std::cout << str << "\n";
        }
        std::cout << "\033[0m";
    }

    template <typename T>
    void writeLine(T str, unsigned int c){
        std::cout << "\033[" << c << "m";
        std::cout << str << "\n";
        std::cout << "\033[0m";
    }

    template <typename T>
    void write(T str){
        std::cout << str;
    }

    template <typename T>
    void write(T str, unsigned short e){
        if(errorLevel == errorLevels.ALL || e == errorLevel && errorLevel != errorLevels.NONE){
            std::cout << str;
        }
    }

    template <typename T>
    void write(T str, unsigned short e, unsigned int c){
        std::cout << "\033[" << c << "m";
        if(errorLevel == errorLevels.ALL || e == errorLevel && errorLevel != errorLevels.NONE){
            std::cout << str;
        }
        std::cout << "\033[0m";
    }

    template <typename T>
    void write(T str, unsigned int c){
        std::cout << "\033[" << c << "m";
        std::cout << str;
        std::cout << "\033[0m";
    }

    template <typename T>
    std::string getInput(T str, unsigned int c){
        write(str, c);
        std::string input = "";
        std::getline(std::cin, input);
        return input;
    }

    template <typename T>
    std::string getInput(T str){
        write(str);
        std::string input = "";
        std::getline(std::cin, input);
        return input;
    }

    template <typename T>
    void printArray(T arr[]){

        if(size(arr) == 0){
            std::cout << "(EMTPY)\n";
            return;
        }

        std::cout << "(";
        for(int i=0; i < size(arr); i++){
            try{
                
                std::cout << arr[i];
                if(i != size(arr)-1){
                    std::cout << ", ";
                }
                else{
                    std::cout << ")\n";
                }
                
            }
            catch(const std::exception& e){
                std::cout << "could not print vec\n";
                std::cerr << e.what() << '\n';
            }
            
        }
    }

    template <typename T>
    void printVector(std::vector<T> vec){

        if(size(vec) == 0){
            std::cout << "(EMTPY)\n";
            return;
        }

        std::cout << "(";
        for(int i=0; i < size(vec); i++){
            try{
                
                std::cout << vec[i];
                if(i != size(vec)-1){
                    std::cout << ", ";
                }
                else{
                    std::cout << ")\n";
                }
                
            }
            catch(const std::exception& e){
                std::cout << "could not print vec\n";
                std::cerr << e.what() << '\n';
            }
            
        }
    }

    


}debugger;
