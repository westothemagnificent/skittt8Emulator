#include <iostream>
#include <vector>
#include <algorithm> // For std::find
#include <map>
#include <optional>
#include <sstream>
#include <fstream>

#include "debugger.hpp"

class Data{
    public:
        std::string name = "";
        std::string value = "";

        Data(std::string Name, std::string Value){
            name = Name;
            value = Value;
        }

        friend std::ostream& operator<<(std::ostream& os, const Data& t) {
            os << t.value << "|" << t.name;
            return os;
        }
};


class chip{
    public:
        std::string name = "";
        std::string value = "";

        std::vector<Data> data = {};

        chip(std::string Name, std::string Value, std::vector<Data> Datav){
            name = Name;
            value = Value;
            data = Datav;
        }
};

class token{
    public:
        std::string str = "";

        token(std::string Str){
            str = Str;
        }

        friend std::ostream& operator<<(std::ostream& os, const token& t) {
            os << t.str;
            return os;
        }

};


std::vector<std::string> delimiters = {
    " ",
    "(",
    ")",
    "$",
    ";",
};

std::vector<chip> chips = {}; 
std::vector<Data> funcs = {};


std::string programSTR = "";


template <typename T>
bool contains(const std::vector<T>& vec, const T& value) {
    return std::find(vec.begin(), vec.end(), value) != vec.end();
}

std::vector<std::string> split(const std::string& str, char delimiter) {
    std::vector<std::string> result;
    std::string current;
    for (char ch : str) {
        if (ch == delimiter) {
            if (!current.empty()) { // Avoid adding empty substrings
                result.push_back(current);
            }
            current.clear();
        } else {
            current += ch;
        }
    }
    if (!current.empty()) { // Add the last segment
        result.push_back(current);
    }
    return result;
}

void removeSpaces(std::string* str) {
    for (size_t i = 0; i < str->size(); ++i) {
        if (str->at(i) == ' ') {
            str->erase(i, 1); // Remove the space character
            --i; // Adjust the index after erasing
        }
    }
}

void removeNewLines(std::string* str) {
    for (size_t i = 0; i < str->size(); ++i) {
        if (str->at(i) == '\n') {
            str->erase(i, 1); // Remove the space character
            --i; // Adjust the index after erasing
        }
    }
}


template <typename MapType>
std::optional<size_t> getKeyIndex(const MapType& map, const typename MapType::key_type& key) {
    size_t index = 0;
    for (const auto& [currentKey, _] : map) {
        if (currentKey == key) {
            return index; // Return the index if the key is found
        }
        ++index;
    }
    return std::nullopt; // Return std::nullopt if the key is not found
}


std::string readFileAsString(const std::string& filePath) {
    std::ifstream file(filePath);
    if (!file.is_open()) {
        debugger.writeLine("(!!)-- file not found or could not be opened", debugger.errorLevels.FATALERRORS, debugger.colors.RED);
    }

    std::ostringstream contentStream;
    contentStream << file.rdbuf(); // Read file content into the stream
    return contentStream.str();   // Convert stream to string
}

void writeFile(const std::string& filename, const std::string& content) {
    // Create and open a file
    std::ofstream file(filename);

    // Check if the file is open
    if (file.is_open()) {
        // Write the content to the file
        file << content;

        // Close the file
        file.close();
    } else {
        debugger.writeLine("(!!)-- file not found or could not be opened", debugger.errorLevels.FATALERRORS, debugger.colors.RED);
    }
}


class{
    public:
        std::vector<token> getTokens(){
            std::vector<std::string> program = {};
            std::vector<token> tokens = {};
            // new scope to keep things clean
            {   
                int lineNum = 0;
                bool isInComment = false;
                std::string tempString = "";
                for(int i = 0; i < programSTR.size(); i++){

                    if(std::string(1, programSTR[i]) == "/"){
                        isInComment = true;
                        
                    }
                    if(std::string(1, programSTR[i]) == "\n" && isInComment){
                        isInComment = false;
                        
                    }
                    if(std::string(1, programSTR[i]) == ";"){
                        lineNum ++;
                    }

                    if(!isInComment){
                        if (contains(delimiters, std::string(1, programSTR[i]))) {
                            if (!tempString.empty()) {
                                removeSpaces(&tempString);
                                removeNewLines(&tempString);

                                if(std::string(1, tempString[0]) == "."){
                                    funcs.push_back(Data(tempString.substr(1, tempString.size()), std::to_string(lineNum-1)));
                                }
                                else{
                                    tokens.push_back(token(tempString));
                                }
                            }
                            tempString = "";
                        } 
                        else {
                            tempString += programSTR[i];
                        }
                    }
                }
            }
            {
                std::string tempString = "";
                for (const auto& str : program) {
                    for (char ch : str) {
                        if (contains(delimiters, std::string(1, ch))) {
                            if(tempString != " " && tempString != ""){
                                removeSpaces(&tempString);
                                tokens.push_back(token(tempString));
                            }
                            tempString = "";
                        }
                        else{
                            tempString += ch;
                        }
                    }
                }
            }
            return tokens;
        }

}tokeniser;

int findChip(std::string name){
    
    for (int i=0; i < chips.size(); i++){

        if(chips[i].name == name){
            return i;
        }
    }
    return -1;
}

int main(int argc, char **argv){
    debugger.errorLevel = debugger.errorLevels.ALL;

    std::vector<std::string> flags;

    for (int i = 1; i < argc; ++i) { // Start from 1 to skip the program name
        std::string arg = argv[i];
        if (!arg.empty() && arg[0] == '-') {
            flags.push_back(arg);
        }
    }

    if(flags.size() >= 1){
        if(flags[0] == "-skitt8"){
            
        }
        else{
            // do the cpu logic when we have another cpu
            debugger.writeLine("(!!)-- not a vaild cpu", debugger.errorLevels.FATALERRORS,  debugger.colors.RED);
            return 1;
        }
    }
    else{
        debugger.writeLine("(!!)-- provide a cpu target to compile for", debugger.errorLevels.FATALERRORS,  debugger.colors.RED);
        return 1;
    }

    for(std::string str : flags){
        if(str == "-help"){
            debugger.writeLine("_-_-_-_-_Skitt inc. Skitt8 Assembler help_-_-_-_-_");
            debugger.writeLine("    Commands: ");
            debugger.writeLine("        -help, shows this screen ");
            debugger.writeLine("    Usage: ");
            debugger.writeLine("        To compile a .skitt8ASM file do 'skitt8Assembler -skitt8OrYourCoolCpu yourProgram.skitt8ASM yourOutput'\n NOTE your cpu target MUST be the frist arrg");
            debugger.writeLine("        To add any flags put them at the END: 'skitt8Assembler -skitt8OrYourCoolCpu yourProgram.skitt8ASM yourOutput -coolFlag'");
            debugger.writeLine("        You will need to read the README.md to find out how the skitt8 cpu works to program well");
            return 0;        
        }
    }

    if(argc > 3){
        debugger.writeLine("(*)-- getting file data", debugger.errorLevels.NOTES,  debugger.colors.GREEN);
        programSTR = readFileAsString(argv[2]);
        debugger.writeLine(argv[2]);
        debugger.writeLine("(*)-- done getting file contents", debugger.errorLevels.NOTES,  debugger.colors.GREEN);
    }
    else{
        debugger.writeLine("(!!)-- provide a file to compile to skitt8ASM code and output file", debugger.errorLevels.FATALERRORS,  debugger.colors.RED);
        std::terminate();
    }


    // RES A
    chips.push_back(chip("resa", "0000", {Data("ldbus", "0000"),   // Load RES A with current BUS data
                                        Data("ldarg", "0001"),   // Load RES A with ARRG 1
                                        Data("out", "0010"),     // Output RES A to BUS
                                        Data("swapb", "1111")})); // Swap RES A and RES B

    // RES B
    chips.push_back(chip("resb", "0001", {Data("ldbus", "0000"),   // Load RES B with current BUS data
                                        Data("ldarg", "0001"),   // Load RES B with ARRG 1
                                        Data("out", "0010"),     // Output RES B to BUS
                                        Data("swapc", "1111")})); // Swap RES B and RES C

    // BUS
    chips.push_back(chip("bus", "0010", {Data("ldarg", "0000")})); // Load RES BUS with ARRG 1

    // ALU
    chips.push_back(chip("au", "0011", {Data("adda", "0000"),      // Add RES A and RES B, store in ALU RES
                                        Data("add", "0001"),       // Add RES A and RES B, store in A
                                        Data("suba", "0010"),      // Sub RES A and RES B, store in ALU RES
                                        Data("sub", "0011"),       // Sub RES A and RES B, store in A
                                        Data("out", "0110")}));    // Output ALU RES to BUS

    // LU
    chips.push_back(chip("lu", "0100", {Data("eq", "0000"),         // Check if RES A == RES B, set ALU RES
                                        Data("eqarg", "0001"),      // Check if RES A == ARRG 1, set ALU RES
                                        Data("gt", "0010"),         // Check if RES A > RES B, set ALU RES
                                        Data("gtarg", "0011"),      // Check if RES A > ARRG 1, set ALU RES
                                        Data("lt", "0100"),         // Check if RES A < RES B, set ALU RES
                                        Data("ltarg", "0101"),      // Check if RES A < ARRG 1, set ALU RES
                                        Data("jmpz", "0110"),       // Jump to ARRG 1 if ALU RES == 0
                                        Data("jmpnz", "0111"),      // Jump to ARRG 1 if ALU RES != 0
                                        Data("nop", "1000"),        // No operation
                                        Data("jmp", "1001"),        // Jump to ARRG 1
                                        Data("halt", "1111")}));    // Halt the computer

    // RES C
    chips.push_back(chip("resc", "0101", {Data("ldbus", "0000"),   // Load RES C with current BUS data
                                        Data("ldarg", "0001"),   // Load RES C with ARRG 1
                                        Data("out", "0010"),     // Output RES C to BUS
                                        Data("swapa", "1111")})); // Swap RES C and RES A

    // IO
    chips.push_back(chip("io", "0110", {Data("prtint", "0000"),    // Output BUS data as an int
                                        Data("prtchr", "0001"),    // Output BUS data as a char
                                        Data("prtintarg", "0010"),
                                        Data("prtchrarg", "0011"),
                                        Data("inchr", "0100"),     // Input char to BUS
                                        Data("inint", "0101")}));  // Input int to BUS

    // RAM
    chips.push_back(chip("ram", "0111", {Data("ldbus", "0000"),    // Load RAM data to BUS
                                        Data("lda", "0001"),      // Load RAM data to RES A
                                        Data("ldb", "0010"),      // Load RAM data to RES B
                                        Data("stbus", "0011"),    // Store BUS data in RAM
                                        Data("sta", "0100"),      // Store RES A data in RAM
                                        Data("stb", "0101"),
                                        Data("stbatab", "0110"), 
                                        Data("ldbatab", "1000"), 
                                        }));   // Store RES B data in RAM

    debugger.writeLine("(*)-- starting compiling", debugger.errorLevels.NOTES,  debugger.colors.GREEN);
    std::vector<token> tokens = tokeniser.getTokens();

    int tokenNum = 0;
    token frist = token("");
    std::string INS = "";
    
    std::string fileContents = "";

    debugger.printVector(tokens);
    debugger.printVector(funcs);

    for (token tok : tokens) {
        if(tok.str != "RETRUN" && tok.str != "READYCALL"){
            if (tokenNum == 0) {
                frist = tok;
                int f = findChip(tok.str);
                if (f != -1) {
                    INS += chips[f].value + "|";
                }

            }
            else if(tokenNum == 1){

                int f = findChip(frist.str);
                int index = -1;
                for(int i=0; i < chips[f].data.size(); i++){
                    if( chips[f].data[i].name == tok.str){
                        index = i;
                        break;
                    }
                }
                INS += chips[f].data[index].value + "[";

            }
            else if (tokenNum == 2) {
                int index = -1;
                for(int i=0; i < funcs.size(); i++){
                    if( funcs[i].name == tok.str){
                        index = i;
                        break;
                    }
                }
                if(index == -1){
                    INS += tok.str + ",";  // Parameter 1
                }
                else{
                    INS += funcs[index].value + ",";
                }
            }
            else if (tokenNum == 3) {
                int index = -1;
                for(int i=0; i < funcs.size(); i++){
                    if( funcs[i].name == tok.str){
                        index = i;
                        break;
                    }
                }
                if(index == -1){
                    INS += tok.str + "]";  // Parameter 1
                }
                else{
                    INS += funcs[index].value + "]";
                }
            }

            tokenNum++;
            if (tokenNum >= 4) {

                // debugger.writeLine(INS);
                fileContents += INS + "\n";
                tokenNum = 0;
                INS = "";
            }
        }
        else{
            if(tok.str == "RETRUN"){
                debugger.writeLine("RETRUN");
                fileContents += "1000|0001[0,0]\n0100|1010[0,0]\n";
            }
            else if(tok.str == "READYCALL"){
                debugger.writeLine("READYCALL");
                fileContents += "1000|0010[0,0]\n";
            }
        }
    }
    writeFile(argv[3], fileContents);
    debugger.writeLine("(*)-- done compiling saving output", debugger.errorLevels.NOTES,  debugger.colors.GREEN);


    return 0;
}